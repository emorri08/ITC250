<!-- footer starts here -->
            
    <!-- Footer -->
    <footer>
      <p class="copyrights"><small>&copy; 2018 - <?php echo date("Y")?> by ITC250 W19 Group 1, All Rights Reserved ~ <a href="http://validator.w3.org/check/referer" target="_blank">Valid HTML</a> ~ <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank">Valid CSS</a></small></p>
    </footer>
<!-- END Footer --> 
</body>
</html>
